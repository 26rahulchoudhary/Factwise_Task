import json
import os
from datetime import datetime
from typing import Dict, List, Optional, TypeVar, Generic, Type

from models import User, Team, Board, Task

T = TypeVar('T')

class Storage(Generic[T]):
    def __init__(self, file_path: str, model_class: Type[T]):
        self.file_path = file_path
        self.model_class = model_class
        self.data: Dict[str, T] = {}
        print(f"Initializing storage for {model_class.__name__} at {file_path}")
        self._load()

    def _load(self):
        try:
            print(f"Loading data from {self.file_path}")
            os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
            if os.path.exists(self.file_path):
                print(f"File exists, reading data")
                with open(self.file_path, 'r') as f:
                    raw_data = json.load(f)
                    for key, value in raw_data.items():
                        # Convert string dates back to datetime objects
                        if isinstance(value, dict):
                            for date_field in ['creation_time', 'end_time']:
                                if date_field in value and value[date_field]:
                                    value[date_field] = datetime.fromisoformat(value[date_field])
                            # Initialize user_details for Team objects if not present
                            if self.model_class == Team and 'user_details' not in value:
                                value['user_details'] = {}
                        self.data[key] = self.model_class(**value)
                print(f"Loaded {len(self.data)} items")
            else:
                print(f"File does not exist, starting with empty data")
                self.data = {}
                self._save()  # Create the file
        except Exception as e:
            print(f"Error loading data from {self.file_path}: {str(e)}")
            self.data = {}
            self._save()

    def _save(self):
        try:
            print(f"Saving data to {self.file_path}")
            os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
            with open(self.file_path, 'w') as f:
                # Convert datetime objects to ISO format strings for JSON serialization
                serializable_data = {}
                for key, value in self.data.items():
                    dict_data = value.model_dump()
                    for date_field in ['creation_time', 'end_time']:
                        if date_field in dict_data and dict_data[date_field]:
                            dict_data[date_field] = dict_data[date_field].isoformat()
                    serializable_data[key] = dict_data
                json.dump(serializable_data, f, indent=2)
            print(f"Saved {len(self.data)} items")
        except Exception as e:
            print(f"Error saving data to {self.file_path}: {str(e)}")
            raise

    def add(self, id: str, item: T):
        print(f"Adding item with id {id} to {self.file_path}")
        self.data[id] = item
        self._save()

    def get(self, id: str) -> Optional[T]:
        return self.data.get(id)

    def get_all(self) -> List[T]:
        return list(self.data.values())

    def update(self, id: str, item: T):
        if id in self.data:
            print(f"Updating item with id {id} in {self.file_path}")
            self.data[id] = item
            self._save()

    def delete(self, id: str):
        if id in self.data:
            print(f"Deleting item with id {id} from {self.file_path}")
            del self.data[id]
            self._save()

class DataStore:
    def __init__(self, db_folder: str = "db"):
        print(f"Initializing DataStore with folder: {db_folder}")
        # Convert to absolute path
        if not os.path.isabs(db_folder):
            db_folder = os.path.abspath(db_folder)
        print(f"Using absolute path: {db_folder}")
        
        # Create the directory if it doesn't exist
        os.makedirs(db_folder, exist_ok=True)
        
        self.users = Storage[User](os.path.join(db_folder, "users.json"), User)
        self.teams = Storage[Team](os.path.join(db_folder, "teams.json"), Team)
        self.boards = Storage[Board](os.path.join(db_folder, "boards.json"), Board)
        self.tasks = Storage[Task](os.path.join(db_folder, "tasks.json"), Task) 