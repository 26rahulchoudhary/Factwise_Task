import json
import os
import uuid
import random
import string
from datetime import datetime
from typing import List

from tabulate import tabulate

from models import User, UserCreate, Team, TeamCreate, Board, BoardCreate, Task, TaskCreate, BoardStatus, TaskStatus
from storage import DataStore
from user_base import UserBase
from team_base import TeamBase
from project_board_base import ProjectBoardBase


def generate_short_id(length: int = 6) -> str:
    """Generate a short alpha-numeric ID with guaranteed mix of letters and numbers"""
    # Ensure at least 2 numbers and 2 letters
    numbers = ''.join(random.choices(string.digits, k=2))
    letters = ''.join(random.choices(string.ascii_letters, k=2))
    
    # Fill the rest with random alphanumeric
    remaining_length = length - 4
    remaining = ''.join(random.choices(string.ascii_letters + string.digits, k=remaining_length))
    
    # Combine and shuffle
    combined = list(numbers + letters + remaining)
    random.shuffle(combined)
    return ''.join(combined)


class UserManager(UserBase):
    def __init__(self, data_store: DataStore):
        self.data_store = data_store

    def create_user(self, request: str) -> str:
        data = json.loads(request)
        user_create = UserCreate(**data)

        # Check if username is unique
        existing_users = self.data_store.users.get_all()
        if any(u.name == user_create.name for u in existing_users):
            raise ValueError("Username must be unique")

        # Generate a unique ID
        while True:
            new_id = generate_short_id()
            if not any(u.id == new_id for u in existing_users):
                break

        user = User(
            id=new_id,
            creation_time=datetime.now(),
            **user_create.model_dump()
        )
        self.data_store.users.add(user.id, user)
        return json.dumps({"id": user.id})

    def list_users(self) -> str:
        users = self.data_store.users.get_all()
        return json.dumps([{
            "name": u.name,
            "display_name": u.display_name,
            "creation_time": u.creation_time.isoformat()
        } for u in users])

    def describe_user(self, request: str) -> str:
        data = json.loads(request)
        user = self.data_store.users.get(data["id"])
        if not user:
            raise ValueError("User not found")
        
        return json.dumps({
            "name": user.name,
            "display_name": user.display_name,
            "creation_time": user.creation_time.isoformat()
        })

    def update_user(self, request: str) -> str:
        data = json.loads(request)
        user = self.data_store.users.get(data["id"])
        if not user:
            raise ValueError("User not found")

        update_data = data["user"]
        if "name" in update_data and update_data["name"] != user.name:
            raise ValueError("Username cannot be updated")

        user.display_name = update_data.get("display_name", user.display_name)
        self.data_store.users.update(user.id, user)
        return ""

    def get_user_teams(self, request: str) -> str:
        data = json.loads(request)
        user_id = data["id"]
        
        teams = [
            team for team in self.data_store.teams.get_all()
            if user_id in team.user_details or team.admin == user_id
        ]
        
        return json.dumps([{
            "name": t.name,
            "description": t.description,
            "creation_time": t.creation_time.isoformat()
        } for t in teams])


class TeamManager(TeamBase):
    def __init__(self, data_store: DataStore):
        self.data_store = data_store

    def create_team(self, request: str) -> str:
        data = json.loads(request)
        team_create = TeamCreate(**data)

        # Check if team name is unique
        existing_teams = self.data_store.teams.get_all()
        if any(t.name == team_create.name for t in existing_teams):
            raise ValueError("Team name must be unique")

        # Verify admin user exists
        if not self.data_store.users.get(team_create.admin):
            raise ValueError("Admin user not found")

        # Generate a unique ID
        while True:
            new_id = generate_short_id()
            if not any(t.id == new_id for t in existing_teams):
                break

        team = Team(
            id=new_id,
            creation_time=datetime.now(),
            **team_create.model_dump()
        )
        self.data_store.teams.add(team.id, team)
        return json.dumps({"id": team.id})

    def list_teams(self) -> str:
        teams = self.data_store.teams.get_all()
        result = []
        for team in teams:
            # Get admin user details
            admin_user = self.data_store.users.get(team.admin)
            admin_display = f"{team.admin} ({admin_user.display_name})" if admin_user else team.admin
            
            # Initialize user_details if not present
            if not hasattr(team, 'user_details'):
                team.user_details = {}
            
            # Format team members
            team_members = []
            for user_id, user_info in team.user_details.items():
                team_members.append(f"{user_id} ({user_info['display_name']})")
            
            result.append({
                "name": team.name,
                "description": team.description,
                "creation_time": team.creation_time.isoformat(),
                "admin": admin_display,
                "user_details": team_members
            })
        return json.dumps(result, indent=2)

    def describe_team(self, request: str) -> str:
        data = json.loads(request)
        team = self.data_store.teams.get(data["id"])
        if not team:
            raise ValueError("Team not found")
        
        # Get admin user details
        admin_user = self.data_store.users.get(team.admin)
        admin_display = f"{team.admin} ({admin_user.display_name})" if admin_user else team.admin
        
        # Initialize user_details if not present
        if not hasattr(team, 'user_details'):
            team.user_details = {}
        
        # Format team members
        team_members = []
        for user_id, user_info in team.user_details.items():
            team_members.append(f"{user_id} ({user_info['display_name']})")
        
        result = {
            "name": team.name,
            "description": team.description,
            "creation_time": team.creation_time.isoformat(),
            "admin": admin_display,
            "user_details": team_members
        }
        return json.dumps(result, indent=2)

    def update_team(self, request: str) -> str:
        data = json.loads(request)
        team = self.data_store.teams.get(data["id"])
        if not team:
            raise ValueError("Team not found")

        update_data = data["team"]
        new_name = update_data.get("name")
        if new_name and new_name != team.name:
            # Check if new name is unique
            existing_teams = self.data_store.teams.get_all()
            if any(t.name == new_name for t in existing_teams if t.id != team.id):
                raise ValueError("Team name must be unique")
            team.name = new_name

        team.description = update_data.get("description", team.description)
        team.admin = update_data.get("admin", team.admin)
        
        self.data_store.teams.update(team.id, team)
        return ""

    def add_users_to_team(self, request: str):
        data = json.loads(request)
        team = self.data_store.teams.get(data["id"])
        if not team:
            raise ValueError("Team not found")

        users_to_add = data["users"]
        if len(team.user_details) + len(users_to_add) > 50:
            raise ValueError("Team cannot have more than 50 users")

        # Initialize user_details if not present
        if not hasattr(team, 'user_details'):
            team.user_details = {}

        # Verify all users exist and store their details
        for user_id in users_to_add:
            user = self.data_store.users.get(user_id)
            if not user:
                raise ValueError(f"User {user_id} not found")
            team.user_details[user_id] = {
                "name": user.name,
                "display_name": user.display_name
            }

        self.data_store.teams.update(team.id, team)

    def remove_users_from_team(self, request: str):
        """Remove users from a team"""
        try:
            # Parse request
            data = json.loads(request)
            team_id = data["id"]
            users_to_remove = data["users"]

            # Get team
            team = self.data_store.teams.get(team_id)
            if not team:
                raise ValueError("Team not found")

            # Cannot remove admin
            if team.admin in users_to_remove:
                raise ValueError("Cannot remove team admin from the team")

            # Remove each user
            for user_id in users_to_remove:
                if user_id in team.user_details:
                    team.remove_user(user_id)

            # Save changes
            self.data_store.teams.update(team.id, team)
            
            print(f"Successfully removed users: {users_to_remove}")
            return ""
        except Exception as e:
            print(f"Error removing users: {str(e)}")
            raise

    def list_team_users(self, request: str):
        data = json.loads(request)
        team = self.data_store.teams.get(data["id"])
        if not team:
            raise ValueError("Team not found")

        result = []
        for user_id, user_info in team.user_details.items():
            result.append({
                "id": f"{user_id} ({user_info['display_name']})",
                "name": user_info['name'],
                "display_name": user_info['display_name']
            })

        return json.dumps(result, indent=2)


class ProjectBoardManager(ProjectBoardBase):
    def __init__(self, data_store: DataStore):
        self.data_store = data_store

    def create_board(self, request: str):
        data = json.loads(request)
        board_create = BoardCreate(**data)

        # Check if team exists
        team = self.data_store.teams.get(board_create.team_id)
        if not team:
            raise ValueError("Team not found")

        # Check if board name is unique for the team
        team_boards = [b for b in self.data_store.boards.get_all() if b.team_id == board_create.team_id]
        if any(b.name == board_create.name for b in team_boards):
            raise ValueError("Board name must be unique for the team")

        # Generate a unique ID
        existing_boards = self.data_store.boards.get_all()
        while True:
            new_id = generate_short_id()
            if not any(b.id == new_id for b in existing_boards):
                break

        board = Board(
            id=new_id,
            **board_create.model_dump()
        )
        self.data_store.boards.add(board.id, board)
        return json.dumps({"id": board.id})

    def close_board(self, request: str) -> str:
        data = json.loads(request)
        board = self.data_store.boards.get(data["id"])
        if not board:
            raise ValueError("Board not found")

        # Check if all tasks are complete
        board_tasks = [t for t in self.data_store.tasks.get_all() if t.board_id == board.id]
        if any(t.status != TaskStatus.COMPLETE for t in board_tasks):
            raise ValueError("Cannot close board with incomplete tasks")

        board.status = BoardStatus.CLOSED
        board.end_time = datetime.now()
        self.data_store.boards.update(board.id, board)
        return ""

    def add_task(self, request: str) -> str:
        data = json.loads(request)
        task_create = TaskCreate(**data)

        # Get the board for this task
        board = self.data_store.boards.get(data.get("board_id"))
        if not board:
            raise ValueError("Board not found")

        if board.status != BoardStatus.OPEN:
            raise ValueError("Can only add tasks to open boards")

        # Check if task title is unique for the board
        board_tasks = [t for t in self.data_store.tasks.get_all() if t.board_id == board.id]
        if any(t.title == task_create.title for t in board_tasks):
            raise ValueError("Task title must be unique for the board")

        # Verify user exists and is part of the team
        user = self.data_store.users.get(task_create.user_id)
        if not user:
            raise ValueError("User not found")

        team = self.data_store.teams.get(board.team_id)
        if task_create.user_id not in team.user_details and task_create.user_id != team.admin:
            raise ValueError("User is not part of the team")

        # Generate a unique ID
        existing_tasks = self.data_store.tasks.get_all()
        while True:
            new_id = generate_short_id()
            if not any(t.id == new_id for t in existing_tasks):
                break

        task = Task(
            id=new_id,
            board_id=board.id,
            **task_create.model_dump()
        )
        self.data_store.tasks.add(task.id, task)
        return json.dumps({"id": task.id})

    def update_task_status(self, request: str):
        data = json.loads(request)
        task = self.data_store.tasks.get(data["id"])
        if not task:
            raise ValueError("Task not found")

        task.status = TaskStatus(data["status"])
        self.data_store.tasks.update(task.id, task)

    def list_boards(self, request: str) -> str:
        data = json.loads(request)
        team_id = data["id"]

        # Verify team exists
        if not self.data_store.teams.get(team_id):
            raise ValueError("Team not found")

        boards = [b for b in self.data_store.boards.get_all() if b.team_id == team_id]
        return json.dumps([{
            "id": b.id,
            "name": b.name
        } for b in boards])

    def export_board(self, request: str) -> str:
        data = json.loads(request)
        board = self.data_store.boards.get(data["id"])
        if not board:
            raise ValueError("Board not found")

        # Get all tasks for this board
        tasks = [t for t in self.data_store.tasks.get_all() if t.board_id == board.id]
        
        # Get user display names
        users = {u.id: u.display_name for u in self.data_store.users.get_all()}

        # Prepare the board information
        board_info = [
            ["Board Name:", board.name],
            ["Description:", board.description],
            ["Status:", board.status],
            ["Created:", board.creation_time.strftime("%Y-%m-%d %H:%M:%S")],
            ["Closed:", board.end_time.strftime("%Y-%m-%d %H:%M:%S") if board.end_time else "N/A"]
        ]

        # Prepare the tasks table
        task_data = []
        for task in tasks:
            task_data.append([
                task.title,
                task.description,
                users.get(task.user_id, "Unknown"),
                task.status,
                task.creation_time.strftime("%Y-%m-%d %H:%M:%S")
            ])

        # Create the output file
        out_dir = "out"
        os.makedirs(out_dir, exist_ok=True)
        out_file = os.path.join(out_dir, f"board_{board.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")

        with open(out_file, "w") as f:
            # Write board information
            f.write("Board Information\n")
            f.write("=================\n\n")
            f.write(tabulate(board_info, tablefmt="plain"))
            f.write("\n\n")

            # Write tasks
            f.write("Tasks\n")
            f.write("=====\n\n")
            f.write(tabulate(
                task_data,
                headers=["Title", "Description", "Assigned To", "Status", "Created"],
                tablefmt="grid"
            ))

        return json.dumps({"out_file": os.path.basename(out_file)})

    def update_board_status(self, request: str) -> str:
        """Update the status of a board"""
        data = json.loads(request)
        board = self.data_store.boards.get(data["id"])
        if not board:
            raise ValueError("Board not found")

        new_status = BoardStatus(data["status"])
        
        # If closing the board, check if all tasks are complete
        if new_status == BoardStatus.CLOSED:
            board_tasks = [t for t in self.data_store.tasks.get_all() if t.board_id == board.id]
            if any(t.status != TaskStatus.COMPLETE for t in board_tasks):
                raise ValueError("Cannot close board with incomplete tasks")
            board.end_time = datetime.now()
        else:
            # If reopening the board, reset end_time
            board.end_time = None
            
        board.status = new_status
        self.data_store.boards.update(board.id, board)
        return "" 