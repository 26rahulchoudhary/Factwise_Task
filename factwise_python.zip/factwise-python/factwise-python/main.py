import json
from storage import DataStore
from implementations import UserManager, TeamManager, ProjectBoardManager

class TeamProjectPlanner:
    def __init__(self):
        self.data_store = DataStore()
        self.user_manager = UserManager(self.data_store)
        self.team_manager = TeamManager(self.data_store)
        self.board_manager = ProjectBoardManager(self.data_store)

    # User Management
    def create_user(self, name: str, display_name: str) -> str:
        request = json.dumps({
            "name": name,
            "display_name": display_name
        })
        return self.user_manager.create_user(request)

    def list_users(self) -> str:
        return self.user_manager.list_users()

    def describe_user(self, user_id: str) -> str:
        request = json.dumps({"id": user_id})
        return self.user_manager.describe_user(request)

    def update_user(self, user_id: str, display_name: str) -> str:
        request = json.dumps({
            "id": user_id,
            "user": {
                "display_name": display_name
            }
        })
        return self.user_manager.update_user(request)

    def get_user_teams(self, user_id: str) -> str:
        request = json.dumps({"id": user_id})
        return self.user_manager.get_user_teams(request)

    # Team Management
    def create_team(self, name: str, description: str, admin_id: str) -> str:
        request = json.dumps({
            "name": name,
            "description": description,
            "admin": admin_id
        })
        return self.team_manager.create_team(request)

    def list_teams(self) -> str:
        return self.team_manager.list_teams()

    def describe_team(self, team_id: str) -> str:
        request = json.dumps({"id": team_id})
        return self.team_manager.describe_team(request)

    def update_team(self, team_id: str, name: str = None, description: str = None, admin_id: str = None) -> str:
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if description is not None:
            update_data["description"] = description
        if admin_id is not None:
            update_data["admin"] = admin_id

        request = json.dumps({
            "id": team_id,
            "team": update_data
        })
        return self.team_manager.update_team(request)

    def add_users_to_team(self, team_id: str, user_ids: list) -> None:
        request = json.dumps({
            "id": team_id,
            "users": user_ids
        })
        self.team_manager.add_users_to_team(request)

    def remove_users_from_team(self, team_id: str, user_ids: list) -> None:
        request = json.dumps({
            "id": team_id,
            "users": user_ids
        })
        self.team_manager.remove_users_from_team(request)

    def list_team_users(self, team_id: str) -> str:
        request = json.dumps({"id": team_id})
        return self.team_manager.list_team_users(request)

    # Board Management
    def create_board(self, name: str, description: str, team_id: str) -> str:
        from datetime import datetime
        request = json.dumps({
            "name": name,
            "description": description,
            "team_id": team_id,
            "creation_time": datetime.now().isoformat()
        })
        return self.board_manager.create_board(request)

    def close_board(self, board_id: str) -> str:
        request = json.dumps({"id": board_id})
        return self.board_manager.close_board(request)

    def add_task(self, title: str, description: str, user_id: str, board_id: str) -> str:
        from datetime import datetime
        request = json.dumps({
            "title": title,
            "description": description,
            "user_id": user_id,
            "board_id": board_id,
            "creation_time": datetime.now().isoformat()
        })
        return self.board_manager.add_task(request)

    def update_task_status(self, task_id: str, status: str) -> None:
        request = json.dumps({
            "id": task_id,
            "status": status
        })
        self.board_manager.update_task_status(request)

    def list_boards(self, team_id: str) -> str:
        request = json.dumps({"id": team_id})
        return self.board_manager.list_boards(request)

    def export_board(self, board_id: str) -> str:
        request = json.dumps({"id": board_id})
        return self.board_manager.export_board(request)

    def update_board_status(self, board_id: str, status: str) -> None:
        """Update the status of a board"""
        request = json.dumps({
            "id": board_id,
            "status": status
        })
        return self.board_manager.update_board_status(request)


# Example usage
if __name__ == "__main__":
    planner = TeamProjectPlanner()

    # Create users
    user1 = planner.create_user("john_doe", "John Doe")
    user2 = planner.create_user("jane_smith", "Jane Smith")
    print("Created users:", planner.list_users())

    # Create a team
    team = planner.create_team("Development Team", "Main development team", json.loads(user1)["id"])
    team_id = json.loads(team)["id"]
    print("Created team:", planner.describe_team(team_id))

    # Add users to team
    planner.add_users_to_team(team_id, [json.loads(user2)["id"]])
    print("Team users:", planner.list_team_users(team_id))

    # Create a board
    board = planner.create_board("Sprint 1", "First sprint board", team_id)
    board_id = json.loads(board)["id"]

    # Add tasks
    task1 = planner.add_task("Implement API", "Create REST API endpoints", json.loads(user1)["id"], board_id)
    task2 = planner.add_task("Write tests", "Add unit tests", json.loads(user2)["id"], board_id)

    # Update task status
    planner.update_task_status(json.loads(task1)["id"], "COMPLETE")
    planner.update_task_status(json.loads(task2)["id"], "COMPLETE")

    # Close board
    planner.close_board(board_id)

    # Export board
    export_result = planner.export_board(board_id)
    print("Board exported to:", json.loads(export_result)["out_file"]) 