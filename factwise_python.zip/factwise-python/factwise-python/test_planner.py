import json
import sys
from main import TeamProjectPlanner

def print_json(data):
    """Pretty print JSON data"""
    print(json.dumps(json.loads(data), indent=2))

class TestPlanner:
    def __init__(self):
        self.planner = TeamProjectPlanner()
        self.user1_id = None
        self.user2_id = None
        self.team_id = None
        self.board_id = None
        self.task1_id = None
        self.task2_id = None

    def test_create_users(self):
        """Test user creation and listing"""
        print("\n=== Testing User Creation ===\n")
        
        # Create users
        print("Creating users...")
        user1 = self.planner.create_user("john_doe", "John Doe")
        self.user1_id = json.loads(user1)["id"]
        print("Created user 1:", user1)

        user2 = self.planner.create_user("jane_smith", "Jane Smith")
        self.user2_id = json.loads(user2)["id"]
        print("Created user 2:", user2)

        print("\nListing all users:")
        print_json(self.planner.list_users())

    def test_create_team(self):
        """Test team creation and user addition"""
        if not self.user1_id or not self.user2_id:
            self.test_create_users()

        print("\n=== Testing Team Creation ===\n")
        
        # Create team
        print("Creating team...")
        team = self.planner.create_team(
            name="Development Team",
            description="Main development team",
            admin_id=self.user1_id
        )
        self.team_id = json.loads(team)["id"]
        print("Created team:", team)

        # Add user to team
        print("\nAdding user to team...")
        self.planner.add_users_to_team(self.team_id, [self.user2_id])
        print("Team users:")
        print_json(self.planner.list_team_users(self.team_id))

    def test_create_board(self):
        """Test board creation"""
        if not self.team_id:
            self.test_create_team()

        print("\n=== Testing Board Creation ===\n")
        
        print("Creating board...")
        board = self.planner.create_board(
            name="Sprint 1",
            description="First sprint board",
            team_id=self.team_id
        )
        self.board_id = json.loads(board)["id"]
        print("Created board:", board)

    def test_manage_tasks(self):
        """Test task creation and status updates"""
        if not self.board_id:
            self.test_create_board()

        print("\n=== Testing Task Management ===\n")
        
        print("Adding tasks...")
        task1 = self.planner.add_task(
            title="Implement API",
            description="Create REST API endpoints",
            user_id=self.user1_id,
            board_id=self.board_id
        )
        self.task1_id = json.loads(task1)["id"]
        print("Created task 1:", task1)

        task2 = self.planner.add_task(
            title="Write tests",
            description="Add unit tests",
            user_id=self.user2_id,
            board_id=self.board_id
        )
        self.task2_id = json.loads(task2)["id"]
        print("Created task 2:", task2)

        print("\nUpdating task status...")
        self.planner.update_task_status(self.task1_id, "COMPLETE")
        self.planner.update_task_status(self.task2_id, "COMPLETE")
        print("Tasks updated")

    def test_board_completion(self):
        """Test board closure and export"""
        if not self.task1_id or not self.task2_id:
            self.test_manage_tasks()

        print("\n=== Testing Board Completion ===\n")
        
        print("Closing board...")
        self.planner.close_board(self.board_id)
        print("Board closed")

        print("\nExporting board...")
        export_result = self.planner.export_board(self.board_id)
        print("Board exported to:", json.loads(export_result)["out_file"])

def run_test(test_name=None):
    """Run a specific test or all tests"""
    test_planner = TestPlanner()
    
    # Available test cases
    test_cases = {
        "users": test_planner.test_create_users,
        "team": test_planner.test_create_team,
        "board": test_planner.test_create_board,
        "tasks": test_planner.test_manage_tasks,
        "complete": test_planner.test_board_completion
    }

    if test_name:
        if test_name not in test_cases:
            print(f"Error: Unknown test case '{test_name}'")
            print("Available test cases:", ", ".join(test_cases.keys()))
            return
        
        try:
            test_cases[test_name]()
            print(f"\n=== Test '{test_name}' completed successfully ===")
        except Exception as e:
            print(f"\nError in test '{test_name}': {str(e)}")
            raise
    else:
        # Run all tests in sequence
        try:
            test_planner.test_create_users()
            test_planner.test_create_team()
            test_planner.test_create_board()
            test_planner.test_manage_tasks()
            test_planner.test_board_completion()
            print("\n=== All tests completed successfully ===")
        except Exception as e:
            print(f"\nError: {str(e)}")
            raise

if __name__ == "__main__":
    # Get test name from command line argument
    test_name = sys.argv[1] if len(sys.argv) > 1 else None
    run_test(test_name) 