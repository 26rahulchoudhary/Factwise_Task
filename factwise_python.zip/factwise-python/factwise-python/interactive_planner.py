import json
import os
from main import TeamProjectPlanner

def print_json(data):
    """Pretty print JSON data"""
    print(json.dumps(json.loads(data), indent=2))

class InteractivePlanner:
    def __init__(self):
        # Move up one directory to ensure we're in the root workspace
        os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.planner = TeamProjectPlanner()

    def show_menu(self):
        """Show the main menu"""
        print("\n=== Team Project Planner ===")
        print("1. User Management")
        print("2. Team Management")
        print("3. Board Management")
        print("4. Task Management")
        print("5. Exit")
        return input("Select an option (1-5): ")

    def user_menu(self):
        """Show the user management menu"""
        print("\n=== User Management ===")
        print("1. Create user")
        print("2. List users")
        print("3. Describe user")
        print("4. Update user")
        print("5. Get user teams")
        print("6. Back to main menu")
        choice = input("Select an option (1-6): ")

        try:
            if choice == "1":
                name = input("Enter username: ")
                display_name = input("Enter display name: ")
                result = self.planner.create_user(name, display_name)
                print("\nUser created:", result)

            elif choice == "2":
                result = self.planner.list_users()
                print("\nAll users:")
                print_json(result)

            elif choice == "3":
                user_id = input("Enter user ID: ")
                result = self.planner.describe_user(user_id)
                print("\nUser details:")
                print_json(result)

            elif choice == "4":
                user_id = input("Enter user ID: ")
                display_name = input("Enter new display name: ")
                self.planner.update_user(user_id, display_name)
                print("\nUser updated successfully")

            elif choice == "5":
                user_id = input("Enter user ID: ")
                result = self.planner.get_user_teams(user_id)
                print("\nUser teams:")
                print_json(result)

            elif choice == "6":
                return

        except Exception as e:
            print(f"\nError: {str(e)}")

    def team_menu(self):
        """Show the team management menu"""
        print("\n=== Team Management ===")
        print("1. Create team")
        print("2. List teams")
        print("3. Describe team")
        print("4. Update team")
        print("5. Add users to team")
        print("6. Remove users from team")
        print("7. List team users")
        print("8. Back to main menu")
        choice = input("Select an option (1-8): ")

        try:
            if choice == "1":
                name = input("Enter team name: ")
                description = input("Enter team description: ")
                admin_id = input("Enter admin user ID: ")
                result = self.planner.create_team(name, description, admin_id)
                print("\nTeam created:", result)

            elif choice == "2":
                result = self.planner.list_teams()
                print("\nAll teams:")
                print_json(result)

            elif choice == "3":
                team_id = input("Enter team ID: ")
                result = self.planner.describe_team(team_id)
                print("\nTeam details:")
                print_json(result)

            elif choice == "4":
                team_id = input("Enter team ID: ")
                name = input("Enter new name (press Enter to skip): ").strip() or None
                description = input("Enter new description (press Enter to skip): ").strip() or None
                admin_id = input("Enter new admin ID (press Enter to skip): ").strip() or None
                self.planner.update_team(team_id, name, description, admin_id)
                print("\nTeam updated successfully")

            elif choice == "5":
                team_id = input("Enter team ID: ")
                users = input("Enter user IDs (comma-separated): ").split(",")
                users = [u.strip() for u in users]
                self.planner.add_users_to_team(team_id, users)
                print("\nUsers added successfully")

            elif choice == "6":
                team_id = input("Enter team ID: ")
                users = input("Enter user IDs to remove (comma-separated): ").split(",")
                users = [u.strip() for u in users]
                self.planner.remove_users_from_team(team_id, users)
                print("\nUsers removed successfully")

            elif choice == "7":
                team_id = input("Enter team ID: ")
                result = self.planner.list_team_users(team_id)
                print("\nTeam users:")
                print_json(result)

            elif choice == "8":
                return

        except Exception as e:
            print(f"\nError: {str(e)}")

    def board_menu(self):
        """Show the board management menu"""
        print("\n=== Board Management ===")
        print("1. Create board")
        print("2. List boards")
        print("3. Close board")
        print("4. Update board status")
        print("5. Export board")
        print("6. Back to main menu")
        choice = input("Select an option (1-6): ")

        try:
            if choice == "1":
                name = input("Enter board name: ")
                description = input("Enter board description: ")
                team_id = input("Enter team ID: ")
                result = self.planner.create_board(name, description, team_id)
                print("\nBoard created:", result)

            elif choice == "2":
                team_id = input("Enter team ID: ")
                result = self.planner.list_boards(team_id)
                print("\nTeam boards:")
                print_json(result)

            elif choice == "3":
                board_id = input("Enter board ID: ")
                self.planner.close_board(board_id)
                print("\nBoard closed successfully")  

            elif choice == "4":
                board_id = input("Enter board ID: ")
                print("\nAvailable statuses: OPEN, CLOSED")
                status = input("Enter new status: ")
                self.planner.update_board_status(board_id, status)
                print("\nBoard status updated successfully")

            elif choice == "5":
                board_id = input("Enter board ID: ")
                result = self.planner.export_board(board_id)
                print("\nBoard exported:", result)

            elif choice == "6":
                return

        except Exception as e:
            print(f"\nError: {str(e)}")

    def task_menu(self):
        """Show the task management menu"""
        print("\n=== Task Management ===")
        print("1. Add task")
        print("2. Update task status")
        print("3. Back to main menu")
        choice = input("Select an option (1-3): ")

        try:
            if choice == "1":
                title = input("Enter task title: ")
                description = input("Enter task description: ")
                user_id = input("Enter assigned user ID: ")
                board_id = input("Enter board ID: ")
                result = self.planner.add_task(title, description, user_id, board_id)
                print("\nTask created:", result)

            elif choice == "2":
                task_id = input("Enter task ID: ")
                print("\nAvailable statuses: OPEN, IN_PROGRESS, COMPLETE")
                status = input("Enter new status: ")
                self.planner.update_task_status(task_id, status)
                print("\nTask status updated successfully")

            elif choice == "3":
                return

        except Exception as e:
            print(f"\nError: {str(e)}")

    def run(self):
        """Run the interactive planner"""
        while True:
            choice = self.show_menu()

            if choice == "1":
                self.user_menu()
            elif choice == "2":
                self.team_menu()
            elif choice == "3":
                self.board_menu()
            elif choice == "4":
                self.task_menu()
            elif choice == "5":
                print("\nGoodbye!")
                break
            else:
                print("\nInvalid option, please try again")

if __name__ == "__main__":
    planner = InteractivePlanner()
    planner.run() 