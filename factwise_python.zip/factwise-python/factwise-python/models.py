from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict
from pydantic import BaseModel, Field, validator


class TaskStatus(str, Enum):
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETE = "COMPLETE"


class BoardStatus(str, Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"


class UserCreate(BaseModel):
    name: str = Field(..., max_length=64)
    display_name: str = Field(..., max_length=64)


class User(UserCreate):
    id: str
    creation_time: datetime


class TeamCreate(BaseModel):
    name: str = Field(..., max_length=64)
    description: str = Field(..., max_length=128)
    admin: str


class TeamMember(BaseModel):
    id: str
    name: str
    display_name: str


class Team(TeamCreate):
    id: str
    creation_time: datetime
    user_details: Dict[str, dict] = {}  # Store user details with IDs

    def remove_user(self, user_id: str):
        """Helper method to remove a user from the team"""
        if user_id in self.user_details:
            del self.user_details[user_id]


class BoardCreate(BaseModel):
    name: str = Field(..., max_length=64)
    description: str = Field(..., max_length=128)
    team_id: str
    creation_time: datetime


class Board(BoardCreate):
    id: str
    status: BoardStatus = BoardStatus.OPEN
    end_time: Optional[datetime] = None


class TaskCreate(BaseModel):
    title: str = Field(..., max_length=64)
    description: str = Field(..., max_length=128)
    user_id: str
    creation_time: datetime


class Task(TaskCreate):
    id: str
    board_id: str
    status: TaskStatus = TaskStatus.OPEN 